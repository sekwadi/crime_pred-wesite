from setuptools import setup

setup(
    name='numpy3',
    version='0.2',
    description='A package for doing cool stuff',
    author='Your Name',
    author_email='your@email.com',
    packages=['numpy3'],
)