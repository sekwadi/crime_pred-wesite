<?php
// Create connection
//$conn = new mysqli("sql210.epizy.com", "epiz_34121291", " zYvP2EB3S099guV ","epiz_34121291_crime_p");
$conn = new mysqli("localhost", "root", "","crime_p");
?>